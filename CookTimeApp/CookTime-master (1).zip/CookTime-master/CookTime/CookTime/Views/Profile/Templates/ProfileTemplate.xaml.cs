﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CookTime.Views.Social.Templates
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ProfileTemplate : ViewCell
    {
        public ProfileTemplate()
        {
            InitializeComponent();
        }
    }
}